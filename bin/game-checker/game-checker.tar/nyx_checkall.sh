for file in /home/wellmangroup/data/*.slg.gz; do perl checkgame.pl $file; echo "$file  result: $?"; done;
